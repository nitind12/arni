<?php
	session_start();
	session_destroy();
	header('Location: http://www.amrapali.ac.in');
?>