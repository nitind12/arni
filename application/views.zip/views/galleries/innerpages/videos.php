<section class="trusted-client-wrapper">
                                <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb');?>  
                                    <h2 class="section-title wow fadeInDown" >Video Gallery</h2>  
                                                      
                                    <div class="row">
                                        <div id="grid">
                                            <div class="portfolio-item col-xs-12 col-md-4 col-sm-4" style="text-align: center">
                                                <iframe width="100%" height="200px" src="https://www.youtube.com/embed/jHauc0qb0_k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                                       
                                            </div><!-- /.portfolio-item -->
                                                                            
                                        </div><!-- /#grid -->
                                    </div><!-- /.row -->
                                </div>
                                <div style="clear:both"></div>  
                            </section>
                        </div>
                    </div>
<div style="clear: both;"><br></div>
            


