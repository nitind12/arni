<section class="trusted-client-wrapper">
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title; ?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Arni research policy provide support for the development and implementation of the university’s research strategy, setting out measures to encourage appropriate behaviours to achieve our strategic aims.</p>
                                        
                                        </div><!-- /.col-md-4 -->    
                                        <div class="col-md-5">
                                        <ul class="list-group">
                                            <h3>Projects Units</h3>
                                            <li class="list-group-item">Orders/Notices/Circullar</li>
                                            <li class="list-group-item">PROJECTS UNIT </li>
                                            <li class="list-group-item">Staff Members </li>
                                            <li class="list-group-item">Projects And Programmes</li>
                                            <li class="list-group-item">On Going Projects</li>
                                            <li class="list-group-item">Under Submission Projects</li>
                                            <li class="list-group-item">Completed Projects</li>
                                            <li class="list-group-item">Special Assistance Programme SAP</li>
                                            <li class="list-group-item">FIST Programme</li>
                                            <li class="list-group-item">WOS</li>
                                            <li class="list-group-item">Prestigious Fellowships And Fellows</li>
                                            <li class="list-group-item">Ramalingaswami Fellowship</li>
                                            <li class="list-group-item">Ramanujan Fellowship</li>
                                            <li class="list-group-item">Energy Bioscience Overseas Fellowship</li>
                                            <li class="list-group-item">Schemes Under Which Funding Is Provided By Various Funding Agencies</li>
                                            <li class="list-group-item">Project Guidelines And Financial Rules</li>
                                            <li class="list-group-item">GFR-2017</li>
                                            <li class="list-group-item">Guidelines For Project Implementation</li>
                                            <li class="list-group-item">FINANCIAL CODE VOLUME I</li>
                                            <li class="list-group-item">J&K Purchase Guidelines</li>
                                            <li class="list-group-item">GUIDELINES FOR CONDUCT OF FIELD SURVEYS</li>
                                            <li class="list-group-item">Guidelines for Consultancy Projects</li>
                                            <li class="list-group-item">latest M.Phil -  Ph.D / I-Ph.D Statutes 2018</li>
                                            <li class="list-group-item">DSIR Exemption Certificate</li>
                                            <li class="list-group-item">Entry Tax Exemption Notification</li>
                                            <li class="list-group-item">Manual for Procurement of Goods</li>
                                            <li class="list-group-item">Overhead charges</li>
                                            <li class="list-group-item">Check List</li>
                                       </ul>
                                    </div>
                                    <div class="col-md-7">
                                        <div style="clear:both; height: 35px">&nbsp;</div>
                                        <iframe src="https://drive.google.com/file/d/19zg7DuJ91zeXeQ2oVyj997byjFqFpxGV/preview" style="width: 100%; height:800px"></iframe>
                                    </div>                           
                                    </div>
                               
                                <div style="clear:both"></div>

                            </section>