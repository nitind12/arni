<section class="trusted-client-wrapper">
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title; ?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Arni research policy provide support for the development and implementation of the university’s research strategy, setting out measures to encourage appropriate behaviours to achieve our strategic aims.</p>
                                        
                                        </div><!-- /.col-md-4 -->    
                                        <div class="col-md-5">
                                        <h3>Research Units</h3>
                                        <ul class="list-group">
                                            <li class="list-group-item">Orders/Notices/Circullar</li>
                                            <li class="list-group-item">Fee In Two Installments</li>
                                            <li class="list-group-item">Revised Fee Structure</li>
                                             <li class="list-group-item">Enhancement In Number Of Scholarship</li>
                                            <li class="list-group-item">Exemption From Payment</li>
                                            <li class="list-group-item">Latest Scholarship Notification</li>
                                         
                                            <li class="list-group-item">Notification Regarding M.Phil Qualified Scholars</li>
                                            <li class="list-group-item"> Latest M.Phil - Ph.D, I-Ph,D Statues</li>
                                            <li class="list-group-item">Plagiarism Check Of Dissertations In Case Of Scholars Pursued M.Phil From Outside Universities</li>
                                            <li class="list-group-item">Consideration Of GATE Qualified Candidates For Scholarships</li>
                                            <li class="list-group-item">Circular Regarding Uniform Policy For Nomination Of Experts For Evaluation Of Dissertation / Thesis</li>
                                            <li class="list-group-item">Latest M.Phil - Ph.D / I-Ph.D Statutes 2018</li>
                                       </ul>
                                    </div>
                                    <div class="col-md-7">
                                        <iframe src="https://drive.google.com/file/d/19zg7DuJ91zeXeQ2oVyj997byjFqFpxGV/preview" style="width: 100%; height:600px"></iframe>
                                    </div>                           
                                    </div>
                               
                                <div style="clear:both"></div>

                            </section>