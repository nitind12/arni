<section class="trusted-client-wrapper">
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title; ?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Under Construction...</p>
                                        
                                        </div><!-- /.col-md-4 -->                              
                                    </div>
                               
                                <div style="clear:both"></div>

                            </section>