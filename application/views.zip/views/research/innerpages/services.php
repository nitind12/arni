<section class="trusted-client-wrapper">
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title; ?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Arni research policy provide support for the development and implementation of the university’s research strategy, setting out measures to encourage appropriate behaviours to achieve our strategic aims.</p>
                                        
                                        </div><!-- /.col-md-4 -->    
                                        <div class="col-md-5">
                                        <h3>Other Services</h3>
                                        <ul class="list-group">
                                            <li class="list-group-item">Faculty Services</li>
                                              <li class="list-group-item">Form For Attending Conferences, Seminars, Workshops, Etc Within India</li>
                                             <li class="list-group-item">Form For Attending Conferences, Seminars, Workshops, Etc Outside India</li>
                                             <li class="list-group-item">Scholar Services</li>
                                             <li class="list-group-item">Research Progress Assessment Format</li>
                                             <li class="list-group-item">Fellowship Claim Form</li>
                                             <li class="list-group-item">Application Form For Grant Of Extention-Re-Registration-Change In Title Etc.</li>
                                             <li class="list-group-item">Prior To 2009</li>
                                             <li class="list-group-item">Declaration Of Originality In Language Subjects</li>
                                             <li class="list-group-item">One Page Format For Synopsis</li>
                                             <li class="list-group-item">Documents Required For Issuance Of Academic Clearance</li>
                                             <li class="list-group-item">Deputation Forms</li>
                                             <li class="list-group-item">J&K Bank Form For Payment Is Made Other Than J&K Bank</li>
                                             <li class="list-group-item">UC Format As Per GFR 2017</li>
                                             <li class="list-group-item">Fellowship Claim Form</li>
                                       </ul>
                                    </div>
                                    <div class="col-md-7">
                                        <div style="clear:both; height: 35px">&nbsp;</div>
                                        <iframe src="https://drive.google.com/file/d/19zg7DuJ91zeXeQ2oVyj997byjFqFpxGV/preview" style="width: 100%; height:800px"></iframe>
                                    </div>                           
                                    </div>
                               
                                <div style="clear:both"></div>

                            </section>