<h3>Contact Us</h3>
<div <?php echo $class_;?>>
<p>
	<h5>Contact Details of Key CTPD officials</h5>
	<b>Dr. Siddhartha Sharma (Director CTPD)</b> -  <a href="mailto:placement@amrapali.ac.in" style="color:#0000ff">placement@amrapali.ac.in</a> <br>
	<b>Prof. Prashant Sharma (Head CTPD Hospitality section)</b> -  <a href="mailto:psharma@amrapali.ac.in" style="color:#0000ff">psharma@amrapali.ac.in</a> <br>
	<b>Mr. Pawan Mehra (Manager CTPD Hospitality Section)</b> -  <a href="mailto:pawanmehra77@gmail.com" style="color:#0000ff">pawanmehra77@gmail.com</a>
</p>
</div>