<!-- For Single Course [FCBM] -->
<div class="panel panel-default">                        
                                                                <div class="panel-heading panel-heading-link" role="tab" id="headingOne">
                                                                    <h2 class="panel-title">
                                                                        <a class="collapsed titlesize" data-toggle="collapse" data-parent="#accordion1" href="#collapse<?php echo $dept_.$loop1; ?>" aria-expanded="false" aria-controls="collapseOne">
                                                                            <?php echo "Faculty of Commerce &amp; Business Management"; ?>
                                                                        </a>
                                                                    </h2>
                                                                </div>
                                                            <div id="collapse<?php echo $dept_.$loop1; ?>" class="panel-collapse collapse">
                                                              <div class="panel-body">
                                                              	<div class="table-responsive">          
												      				<table class="table" style="font-size: 12px">
															        <thead>
															          <tr>
															            <th>COURSE</th>
															            <th>COMPANY</th>
															            <th>DESIGNATION</th>
															            <th>STUDENT PLACED</th>
															            <th>YEAR</th>
															          </tr>
															        </thead>
															        <?php if($pl_FCBM != 'yes' && $pl_FCBM == $loop1){ ?>
															          	<tr>
															          		<td colspan="4" align="left" style="font-size: 13px; color: #ff0000">Updating...</td>
															          	</tr>
															        <?php } ?>
																        <?php foreach ($placement_FCBM as $item) { ?>
														            		<?php if($item->YEAR == $loop1){ ?>
																	        <tbody>
																	          <tr>
																	            <td style="width:120px;"><?php echo $item->CRS_NAME;?></td>
																	            <td><?php echo $item->COMPANY;?></td>
																	            <td><?php echo $item->DESIG_PROFILE;?></td>
																	            <td><?php echo $item->STUDENT_PALCED;?></td>
																	            <td><?php echo $item->YEAR;?></td>
																	          </tr>
																	        </tbody>
																	        <?php } ?>
													            		<?php } ?>
															      </table>
														      	</div>
                                                              </div>
                                                            </div>
                                                          </div>
			        	<!-- End of Single Course [FCBM] -->