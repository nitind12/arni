<h3>Our Intellectual capital</h3>
<div <?php echo $class_;?>>
<p>
                                                
<div class="job-details" style="margin-top: 20px;">
    <div class="panel-group" id="accordion1">
        <?php $this->load->view('mentor/innerpages/mentorlist/ftca');?>
        <?php $this->load->view('mentor/innerpages/mentorlist/fhm');?>
        <?php $this->load->view('mentor/innerpages/mentorlist/fcbm');?>
        <?php $this->load->view('mentor/innerpages/mentorlist/fps');?>
    </div>
</div><!-- /.entry-content -->
</p>
</div>