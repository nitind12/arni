<section class="trusted-client-wrapper">
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title;?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                            <p>In case of withdrawal of Admission after Full/ Partial Fee Payment, the One-Time Admission charges (Inclusive of Security Amount) mentioned in the Fee Structure will be deducted by the University.</p>                                        
                                        </div>  

                                    </div>
                                    <div style="clear:both"></div>
                                    <div class="col-md-12">
                                        <div class="col-md-12">
                                        <ul class="list-group">
                                            <li class="list-group-item list-group-item-success" style="padding:5px!important;">Top Private Management College in Himachal Pradesh</li>
                                            <li class="list-group-item list-group-item-danger" style="padding:5px!important;">AICTE Approved & Industry 4.0 Ready Program</li>
                                            <li class="list-group-item list-group-item-success" style="padding:5px!important;">2-Time Notified By UGC</li>
                                            <li class="list-group-item list-group-item-danger" style="padding:5px!important;">Excellent Placement Record</li>
                                            <li class="list-group-item list-group-item-success" style="padding:5px!important;">Vibrant Campus Life</li>
                                            <li class="list-group-item list-group-item-danger" style="padding:5px!important;">Nurturing Socially Responsible Students.</li>
                                            <li class="list-group-item list-group-item-success" style="padding:5px!important;">Opportunity to Pursue Tech Management After 12th</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div style="clear:both"></div>
                                </section>