<div class="scholarship-tab">
	All scholarships we know of are featured in our Arni. This feature allows you to find a scholarship that fits for you. <br>
	<a href="<?php echo site_url('#');?>" style="color: #ffff00; text-decoration-line: underline !important;text-decoration-style: double !important;">Click for details</a>...
</div>
<div style="clear: both; padding: 3px 0px"></div>