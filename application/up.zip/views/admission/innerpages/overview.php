<h3>Overview</h3>
<div <?php echo $class_;?>>
<p>
	<b>Highly ranked Institute preparing professionals for the Real World</b>
</p>
<p>
	At AGI, we don't just teach theory we teach you how to put theory into practice. Study with us so that you can take your ideas and make them <b>REAL</b>. We feel extremely privileged to have been able to provide manpower resources to drive the country's growth engine since the year 1999, the group has been able to <b>place more than 75% students</b> in various companies year after year.
</p>
<p>
	The lush green eco friendly campus is spread across 19 acres of land. The campus houses state of art facilities and rich labs to provide students an opportunity to get trained and have right mix of skill sets as per the Industry requirement. It has <b>around 3500 students</b> all part of country. AGI has tied up with numerous companies for the training and skill enhancement of its students.
</p>
<p>
	The rich academic environment of the group focuses on all around development of a personality making it rich in terms of soft skills, technical skills, collaborative skills and rich with human values.
</p>