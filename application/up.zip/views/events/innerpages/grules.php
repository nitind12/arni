
                                                    <h2>General Rules</h2>
                                                    <ul class="check-square">
                                                    	<li>The Event is open for students only (Age Group 14-25).</li>
                                                        <li>Students may participate in multiple activities.</li>
                                                        <li>All Events are individual events. However, Instrument support may be taken in Singing.</li>
                                                        <li>All Participants shall receive an E Certificate. The Winners will receive Trophy and Printed Certificate.</li>
                                                        <li>Advance Registration is compulsory. The registration link is www.amrapali.ac.in/wintercarnival.</li>
                                                        <li>The Result shall be announced on the basis Online Voting* (Views, Likes, Comments) and Judgement by Experts.  (*Leaving Quiz)</li>
                                                        <li>Submission of Copied/ Plagiarised/ Duplicate/ Copyrighted Content shall lead to disqualification. </li>
                                                        <li>The content shared by participants shall be posted on AGIs Social Media Accounts for Public Viewing and Voting.</li>

                                                    </ul>