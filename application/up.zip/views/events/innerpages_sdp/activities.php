
                                                    <h2>List of Activities</h2>
                                                    <ul class="check-square" style="padding: 0px 0px 0px 50px !important">
                                                    	<li>Career Counselling Sessions.</li>
                                                        <li>Technical Workshops.</li>
                                                        <li>Personality Development Workshops.</li>
                                                        <li>Amrapali Knowledge Wizard.</li>
                                                        <li>Amrapali Talent Hunt.</li>
                                                        <li>Amrapali Winter Carnival.</li>
                                                        <li>Amrapali Summer Carnival. </li>
                                                        <li>Campus Star Competition.</li>
                                                        <li>Series of  Quizzes </li>
                                                        <li>Painting/ Sketching Competition</li>
                                                        <li>Dancing/ Singing/ Poetry Competition</li>
                                                        <li>Debates/ Speech Competition</li>
                                                        <li>Essay/ Blog/ Vlog Competition</li>
                                                        <li>Project Competition</li>
                                                        <li>Sports (Cricket, Football, Volleyball, Athletics, Basketball, Badminton, Indoor Games)</li>
                                                    </ul>