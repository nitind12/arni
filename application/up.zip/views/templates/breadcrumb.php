<ol class="breadcrumb">
    <li><a href="<?php echo site_url();?>">Home</a></li>
    <li class="active" style="color: #808080"><?php echo $breadcrumb; ?></li>
</ol>