<!--div class="ticker-container">
                                                <div class="ticker-caption">
                                                    <p>RECENT NEWS</p>
                                                </div>
                                                <ul>
                                                    <?php //foreach ($alumni['rnews_'] as $item) { ?>
                                                        <div>
                                                            <li><span><?php //echo $item->SUBJECT; ?> &ndash; 
                                                                    <?php //if ($item->PATH_ATTACH != 'x') { ?>
                                                                        <a href="<?php //echo ADMIN___ . '/_assets_/newsdetail/' . $item->PATH_ATTACH; ?>" target="_blank" >click for detail</a><br />
                                                                    <?php //} ?>
                                                                </span></li>
                                                        </div>
                                                    <?php //} ?>                                                                                                        
                                                </ul>
                                            </div-->