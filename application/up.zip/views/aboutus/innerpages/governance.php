<section class="trusted-client-wrapper">
        <div class="col-md-8">
            <h2 class="section-title wow fadeInDown" >Governance</h2>                             
        </div>
        
        <div class="col-md-12" style="clear: both"></div>
        
        <div class="col-md-12" style="clear: both; padding: 10px 0px"></div>
    
    <div style="clear:both"></div>

    <div class="panel-group" id="accordion">
        <div class="panel panel-primary">
            <div class="panel-heading">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                        Board of Governors</a>
                    </h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse">
                <div class="panel-body">
                    <p>Coming Soon</p>
                </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                    Board of Management</a>
                </h4>
            </div>
            <div id="collapse2" class="panel-collapse collapse">
            <div class="panel-body">
            <p>Coming Soon</p>
            </div>
            </div>
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                Academic Council</a>
            </h4>
            </div>
            <div id="collapse3" class="panel-collapse collapse">
                <div class="panel-body">
                <p>Coming Soon</p>
                </div>
            </div>
        </div>

        <div class="panel panel-primary">
            <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
                Board of Examination</a>
            </h4>
            </div>
            <div id="collapse4" class="panel-collapse collapse">
                <div class="panel-body">
                <p>Coming Soon</p>
                </div>
            </div>
        </div>

        <div class="panel panel-primary">
            <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">
                Board of Research</a>
            </h4>
            </div>
            <div id="collapse5" class="panel-collapse collapse">
                <div class="panel-body">
                <p>Coming Soon</p>
                </div>
            </div>
        </div>

        <div class="panel panel-primary">
            <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
                Organizational Structure</a>
            </h4>
            </div>
            <div id="collapse6" class="panel-collapse collapse">
                <div class="panel-body">
                <p>Coming Soon</p>
                </div>
            </div>
        </div>
    </div>
</section>