<?php
	$d['alumni_record'] = array (
		[
			'speak' => "FPS has an edge over other pharmacy colleges in the region with regards to its excellent location, serene surroundings, infrastructure, smart classes, wifi and well equipped laboratories. Faculty members are dedicated, helpful and provide mentorship to each student . I am extremely proud to be a part of Amrapali family.",
			'pic' => 'sample.jpg',
			'alumni' => 'Alisha Kesarwani',
			'designation' => 'B. Pharm  2nd Sem',
			'company' => '',
			'class' => 'alumni_1'
		],
		[
			'speak' => "FPS under the flagship of Amrapali Group of Institutes provides students ample opportunities to develop their talents, leadership qualities and social responsibility through various extracurricular and co curricular activities along with sound academics.",
			'pic' => 'sample.jpg',
			'alumni' => 'Shivani Negi',
			'designation' => 'B. Pharm  2nd Sem',
			'company' => '',
			'class' => 'alumni_2'
		],
		[
			'speak' => "FPS provides   an all round experience. The practical sessions were much more emphasized upon, which has helped me in my studies.",
			'pic' => 'sample.jpg',
			'alumni' => 'kesley Bery',
			'designation' => 'Diploma first year',
			'company' => '',
			'class' => 'alumni_1'
		],
		[
			'speak' => "FPS  is giving  me exposure to interesting people, situations, and challenged me in ways that are  new to me. The curriculum, the faculty, and the students provided the environment to stimulate my learning.",
			'pic' => 'sample.jpg',
			'alumni' => 'Himani Bhatt',
			'designation' => 'Diploma First year',
			'company' => '',
			'class' => 'alumni_2'
		],
	);
?>
<?php $this->load->view('academics/fac/student_slider', $d); ?>