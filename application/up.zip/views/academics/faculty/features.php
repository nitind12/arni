<ul class="list-group">
                                                <li class="list-group-item list-group-item-success" style="padding:5px!important;">Top Private Management College in Himachal Pradesh</li>
                                                <li class="list-group-item list-group-item-danger" style="padding:5px!important;">AICTE Approved & Industry 4.0 Ready Program</li>
                                                <li class="list-group-item list-group-item-success" style="padding:5px!important;">2-Time Notified By UGC</li>
                                                <li class="list-group-item list-group-item-danger" style="padding:5px!important;">Excellent Placement Record</li>
                                                <li class="list-group-item list-group-item-success" style="padding:5px!important;">Vibrant Campus Life</li>
                                                <li class="list-group-item list-group-item-danger" style="padding:5px!important;">Nurturing Socially Responsible Students.</li>
                                                <li class="list-group-item list-group-item-success" style="padding:5px!important;">Opportunity to Pursue Tech Management After 12th</li>
                                            </ul>