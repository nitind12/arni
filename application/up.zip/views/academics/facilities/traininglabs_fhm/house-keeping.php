<p>The Housekeeping department is also well equipped with a mock suite room and also it has an operational laundry. The following are the facilities available with respect to housekeeping department</p>
                        <ul>
                            <li>Suite Room- where students are taught the basics of bed making, morning &amp; evening service etc.</li>
                            <li>Laundry</li>
                        </ul>