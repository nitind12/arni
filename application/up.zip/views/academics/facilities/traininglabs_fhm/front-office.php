<ul>
                        <li>Reception desk</li>
                            <li>Bell Desk</li>
                            <li>Lobby area</li>
                            <li>Back Office with Computerized Reservation System</li> 
                    </ul>