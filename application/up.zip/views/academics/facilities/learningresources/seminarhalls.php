                    <ul>
                        <li>Amrapali provides state-of-the-art 9 seminar halls, each with a seating capacity for 150 people that act as a common ground for students, faculty, and corporate personalities for regular interfaces, conferences and other events.     </li>  
                        <li>At these platforms, you will come across various global thought leaders, academic gurus, corporate heads, sharing their corporate experiences with you  </li> 
                        <li>The Seminar Halls are equipped with advanced presentation tools </li>
                    </ul>