	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/clsrm.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>The spacious classrooms in Campuses provide the most conducive atmosphere for dynamic and focused discussions</li>	 
                        <li>They have been designed to bring together analysis with action and are augmented with integrated audio-visual teaching aids for lectures, presentations etc.	</li>
                        <li>Special sessions and classes are held on personality development, business etiquettes, effective communication, leadership, teamwork and analytical skills	</li>
                        <li>All classrooms are spacious and well lit to create the right atmosphere for long hours of learning</li>
                    </ul>
            </div>