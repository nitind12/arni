<div class="col-sm-4">
	<ul>
	<img class="img-responsive" hspace="10" vsapce="10" src="<?php echo base_url('assets/img/computer.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>Entire campus is inter-connected through a highly secured Virtual Private Network, where over 1,000 PCs are inter-connected to the internet through broadband connection	</li>	 
                        <li>The campuses has state-of-the-art computer centre that provide computing facilities comprising of the latest machines linked to a wide range of software, communication and print services		</li>
                        <li>The campus is fully wireless and students use their laptops to help them access the world anytime, anywhere	</li>
                        <li>Latest software like SAS, ORACLE etc. are used to enable work on data analysis, web technologies and software designing</li>
                        <li>The Intranet enables close on-line interaction between faculty and students for online interaction</li>
                    </ul>
            </div>