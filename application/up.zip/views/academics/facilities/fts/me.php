<ul>
	<li>Applied Thermodynamics Lab</li>
                    <li>Automobile Engineering Lab</li>
                    <li>Basic Civil Engineering Lab</li>
                    <li>Basic Mechanical Engineering Lab</li>
                    <li>Computer Aided Manufacturing Lab</li>
                    <li>Engineering Drawing Lab</li>
                    <li>Engineering Mechanics Lab</li>
                    <li>Fluid Machinery Lab</li>
                    <li>Fluid Mechanics Lab</li>
                    <li>Heat &amp; Mass Transfer Lab</li>
                    <li>Machine Drawing Lab</li>
                    <li>Manufacturing Science Lab</li>
                    <li>Material Science and Testing Lab</li>
                    <li>Measurement and Metrology Lab</li>
                    <li>Measurement and Metrology Lab</li>                
                    <li>Refrigeration &amp; Air Conditioning Lab</li>
                    <li>Theory of Machines Lab</li>
                    <li>Workshop</li>
</ul>