<ul>
	<li>Electrical Drives</li>
                    <li>Power System</li>
                    <li>Basic Electrical</li>
                    <li>Control System</li>
                    <li>Electrical Workshop</li>
                    <li>Electromechanical Energy Conversion - I</li>
                    <li>Electromechanical Energy Conversion – II</li>
                    <li>Microprocessor</li>
                    <li>Network &amp; Measurement</li>
                    <li>Power Electronics</li>
                    <li>Power Simulation</li>
                    <li>Workshop Technology</li>
                    <li>Engineering Drawing</li>  
</ul>