<ul>
	<li>Analog Integrated Circuits</li>
                    <li>Analog Communication</li>
                    <li>Basic Electronics</li>
                    <li>Digital Electronics</li>
                    <li>Digital Communication</li>
                    <li>Digital Signal Processing </li>
                    <li>Microwave</li>
                    <li>Optical Fibre Communication</li>
                    <li>Printed Circuit Board</li>
                    <li>Simulation</li>
                    <li>Electronic Devices and Circuits</li>
                    <li>Computer Aided Design</li>
</ul>