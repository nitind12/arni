<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>AMRAPALI GROUP OF INSTITUTES</title>
    	
</head><!--/head-->
<body leftmargin="0" topmargin="0">
	<div style="float: left; width: 100%; padding: 0px">
	<iframe src="https://docs.google.com/a/amrapali.ac.in/forms/d/e/1FAIpQLSe3UGbrNOf5HPBLvhSSp53jH-3t6cOgJUyBy8AdXLDK4qFjZQ/viewform?embedded=true" width="100%" height="5250" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
	</div>
</body>
</html>