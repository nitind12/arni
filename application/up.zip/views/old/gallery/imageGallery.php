    <link href="<?PHP echo base_url() . 'assets/js/gallery/fancyBox/jquery.fancybox.css?v=2.0.5';?>" rel="stylesheet" type="text/css" media="screen" />
    <link href="<?PHP echo base_url() . 'assets/js/gallery/jquery.picasagallery.css';?>" rel="stylesheet" type="text/css" media="screen" />
    <link href="<?PHP echo base_url() . 'assets/js/gallery/fancyBox/helpers/jquery.fancybox-thumbs.css?v=2.0.5';?>" rel="stylesheet" type="text/css" media="screen" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script src="<?PHP echo base_url() . 'assets/js/gallery/fancyBox/jquery.mousewheel-3.0.6.pack.js';?>" type="text/javascript"></script>
    <script src="<?PHP echo base_url() . 'assets/js/gallery/fancyBox/jquery.fancybox.pack.js?v=2.0.5';?>" type="text/javascript"></script>
    <script src="<?PHP echo base_url() . 'assets/js/gallery/fancyBox/helpers/jquery.fancybox-thumbs.js?v=2.0.5';?>" type="text/javascript"></script>
    <script src="<?PHP echo base_url() . 'assets/js/gallery/jquery.picasagallery.js';?>" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() { $('.picasagallery').picasagallery({username:'photoamrapali'}); } );
    </script>
    
    <!--/#title-->
    <section id="about-us" class="container">
        <div class="row">
			<div style="margin:auto;max-width:auto;">
    			<div style='margin:10px 10px 10px 20px; padding:5px; background:none; clear:both;'>
        			<div class='picasagallery'></div>
        		</div>
			</div>
        </div><!--/.row-->
	</section>
    