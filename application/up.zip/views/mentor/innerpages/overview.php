<h3>Overview</h3>
<div <?php echo $class_;?>>
<p>
At Amrapali your dream begins with a teacher who believes in you, who nurtures and leads you to the next plateau, sometimes poking you with a sharp stick called “truth". The academic and the professional Gurus guide young talent in reaching the pinnacle of glory and success. Besides classroom teaching, mentors guides, inspires, motivates and counsel students by their intellectual leadership and dedication by imparting theoretical and technical skills and corporate work ethics.
</p>
<p>
Around 200+ full-time faculty members and various visiting-faculty members, who constitute our intellectual capital are committed to the cause of creating future managers and technocrats with a difference. They focus on learner centric quality delivery using appropriate pedagogy. They strive to add new dimensions to existing course material by continuously incorporating changes that are inspired by developments in the corporate world.
</p>