<ul>
		<li><a href="<?php //echo _yt_;?>" title="<?php echo _yt_title;?>" target="_blank"><i class="fa fa-youtube" style="font-size:25px;"></i></a></li>
		<li><a href="<?php //echo _f_;?>" title="<?php echo _f_title;?>" target="_blank"><i class="fa fa-facebook" style="font-size:20px;"></i></a></li>
		<li><a href="<?php //echo _tw_;?>" title="<?php echo _tw_title;?>" target="_blank"><i class="fa fa-twitter" style="font-size:20px;"></i></a></li>
		<li><a href="<?php //echo _blog_;?>" title="<?php echo _blog_title;?>" target="_blank"><i class="fa fa-bold" style="font-size:20px;"></i></a></li>
		<li><a href="<?php //echo _insta_;?>" title="<?php echo _insta_title;?>" target="_blank"><i class="fa fa-instagram" style="font-size:20px;"></i></a></li>
		<li><a href="<?php //echo _in_;?>" title="<?php echo _in_title;?>" target="_blank" title="share on linkedin"><i class="fa fa-linkedin" style="font-size:20px;"></i></a></li>
		
</ul>