<div class="sidebar-wrapper"  align="left">
                                                <aside class="widget widget_categories">
                                                    <h2 class="widget-title">QUICK LINKS</h2>	
                                                    <ul>
                                                        <!--li><a href="<?php echo site_url('admissions/applynow');?>"><i class="fa fa-cog fa-spin"></i> Apply Online</a></li-->
                                                        <li><a href="<?php echo site_url('admissions/procedure');?>">Admission Procedure</a></li>
                                                        <li><a href="<?php echo site_url('admissions/eligibility_fee');?>">Fee Structures</a></li>
                                                        <li><a href="<?php echo site_url('placements/overview');?>">Training &amp; Placement</a></li>
                                                        <li><a href="<?php echo site_url('about/futurevision');?>">Vision 2025</a></li>                                                        
                                                        <li><a href="<?php echo site_url('contactus');?>">Contact Us</a></li>
                                                    </ul>
                                                </aside>                                                
                                            </div><!-- /.sidebar-wrapper -->