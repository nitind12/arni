<style>
    .advantage{
        font-size:40px;
        color:#010066;
    }
</style>
<section class="trusted-client-wrapper">
                                    <div class="col-md-7">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title;?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                            <p>Scholarships here...</p>                                        
                                        </div><!-- /.col-md-4 -->                               
                                    </div>
                                    <div class="col-md-5">
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                            <?php $this->load->view('academics/faculty/features'); ?>        
                                        </div><!-- /.col-md-4 -->                               
                                    </div>

                                <div style="clear:both"></div>
                            </section>
                            