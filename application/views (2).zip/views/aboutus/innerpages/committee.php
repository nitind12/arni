<section class="trusted-client-wrapper">
        <div class="col-md-12">
        <?php $this->load->view('templates/breadcrumb'); ?>  
            <h2 class="section-title wow fadeInDown" >University Committees</h2>  
            <ul>                   
                <li class="sky alert alert-success">      <a href="/UNIVERSITYCOMMITTEES/AntiRaggingCommittee">Anti-Ragging Committee   Contact Person :           Mobile:      EmailID: </a>                                                      </li>  
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/HostelDisciplineCommittee">Hostel Discipline Committee</a>                          </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/ProctorialBoard">Proctorial Board</a>                                               </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/SCSTWelfareCommittee">SC/ST Welfare Committee</a>                                   </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/SocialandCulturalCommittee">Social &amp; Cultural Committee</a>                         </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/SportsandAthleticsCommittee">Sports &amp; Athletics Committee</a>                       </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/StudentGrievanceCommittee">Student Grievance Committee</a>                          </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/TechnologyIncubationandInnovationCell">Technology Incubation &amp; Innovation Cell</a>  </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/UniversityDisciplineCommittee">University Discipline Committee</a>                  </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/InternalComplaintsCommittee">Internal Complaints Committee (ICC)</a>                </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/StudentsConsultativeCommittee">Students Consultative Committee</a>                  </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/WomenWelfareCell">Women Welfare Cell</a>                                            </li>
                <li class="sky alert alert-success">  <a href="/UNIVERSITYCOMMITTEES/FinanceCommittee">Finance Committee</a>                                             </li>
                <li class="sky alert alert-danger">  <a href="/UNIVERSITYCOMMITTEES/EmployeeGrievanceCommittee">Employee Grievance Committee</a>                        </li>
            </ul>                             
        </div>
        
       
    <div style="clear:both"></div>
    </div>
    
</section>