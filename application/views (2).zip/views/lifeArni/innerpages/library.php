<section class="trusted-client-wrapper">
    <div class="col-md-12">
    <?php $this->load->view('templates/breadcrumb'); ?>  
        <h2 class="section-title wow fadeInDown" ><?php echo $title;?></h2>
        <div class="col-md-12" style="border: #fff solid 0px">
        <p><b><i>All are fully Wi-Fi blocks</i></b></p>
            <p>The University Library has been up-graded to the Best Library in the state of Himachal Pradesh and in the entire surrounding areas. It has now approx 28000 books of different streams , has facilities of e-journals and is fully air-conditioned to provide ideal environment for the students. The Library has a large number of national and international journals in the field of Management, Technology, Science and Arts.</p>
        </div><!-- /.col-md-4 -->     
                                  
    </div>
    <div style="clear:both"></div>
    <div class="col-sm-12">
        <div style="clear:both; height: 20px"></div>
        <div class="col-md-3">
            <img src="<?php echo base_url("/assets/arniImage/library/lib1.jpg"); ?>?version=2.2" alt="Arni Hostel" class="img-thumbnail">
        </div>
        <div class="col-md-3">
            <img src="<?php echo base_url("/assets/arniImage/library/lib2.jpg"); ?>?version=2.2" alt="Arni Hostel" class="img-thumbnail">
        </div>
        <div class="col-md-3">
            <img src="<?php echo base_url("/assets/arniImage/library/lib3.jpg"); ?>?version=2.2" alt="Arni Hostel" class="img-thumbnail">
        </div>
        <div class="col-md-3">
            <img src="<?php echo base_url("/assets/arniImage/library/lib4.jpg"); ?>?version=2.2" alt="Arni Hostel" class="img-thumbnail">
        </div>
    </div>
    
<div style="clear:both"></div>
</section>
                            