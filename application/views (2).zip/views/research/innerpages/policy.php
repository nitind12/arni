<section class="trusted-client-wrapper">
                                
                                    <div class="col-md-12">
                                    <?php $this->load->view('templates/breadcrumb'); ?>  
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title; ?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Arni research policy provide support for the development and implementation of the university’s research strategy, setting out measures to encourage appropriate behaviours to achieve our strategic aims.</p>
                                        
                                        </div><!-- /.col-md-4 -->                               
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <iframe src="https://drive.google.com/file/d/19zg7DuJ91zeXeQ2oVyj997byjFqFpxGV/preview" style="width: 100%; height:600px"></iframe>
                                    </div>
                               
                                <div style="clear:both"></div>

                            </section>