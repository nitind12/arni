<h3>Infrastructure</h3>
<div <?php echo $class_;?>>
<p>	
	At FHM the focus is on overall development of our budding professionals through participation in various activities of team building, skill development, business planning etc. Students get trained in well equipped Labs which include:<br>
	<ul class="mylist" style="line-height: 1.5em">
		<li>Advanced Training Kitchen</li>
		<li>Bulk Training Kitchen</li>
		<li>Basic Training Kitchen</li>
		<li>Bakery and Patisserie Lab</li>
		<li>Cold Kitchen</li>
		<li>Advance Training Restaurant and Bar</li>
		<li>Basic Training Restaurant and Bar</li>
		<li>Training Restaurants</li>
		<li>Cafeteria</li>
		<li>Front Office Labs</li>
		<li>Laundry Lab</li>
		<li>House Keeping Labs</li>
		<li>Suite</li>
		<li>House Keeping Training Rooms</li> 
		<li>Computer Labs</li>
		<li>Conference Room </li>
		<li>Language Lab</li>
		<li>Seminar Hall</li>
		<li>Ventilated Classrooms</li>
		<li>Tutorial rooms</li>
	</ul>
</p>
</div>

<div <?php echo $class_; ?>>
	<p>
		The ERP based monitoring is done to support the Mentoring System to nurture the performance of the students and address their difficulties. Each student's performance record is maintained and accordingly every student is counselled for excellence in specific areas.
	</p>
</div>