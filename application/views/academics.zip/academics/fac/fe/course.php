<h3>Courses</h3>
<div <?php echo $class_;?>>
<p style="text-align: center">
	<iframe src="<?php echo base_url('assets/b_Ed/002.pdf');?>" style="width: 100%; height:700px" frameborder="0"></iframe>    
</p>
</div>