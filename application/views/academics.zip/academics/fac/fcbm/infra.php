
<h3>Infrastructure</h3>
<div <?php echo $class_;?>>
	<p>	
		At Faculty of Commerce and Business Management we speak of state of art infrastructure that facilitates learning alongside qualified and highly experienced and committed teachers.
		<br> 
		Keeping in mind the physical resources that are necessarily required to enhance teaching and learning we have:
		<ul class="mylist" style="line-height: 1.5em">
			<li>Spacious Classrooms fitted with Audio Visual Equipments</li>
			<li>Well Equipped Library with access to Digital E-Journals and E-Books </li>
			<li>Communication Lab for Effective Communication Classes</li>
			<li>Computer Lab with Most Recent Processors </li>
			<li>Conference and Seminar Rooms </li>
		</ul>
	</p>
</div>