<h3>News & Events</h3>
<div <?php echo $class_;?>>
<p>	
	<?php $this->load->view('templates/clg_news');?>
</p>
</div>