<?php $d['crs'] = $alumni_record; ?>
<?php $this->load->view('academics/fac/alumni_slider', $d); ?>