<p>The institute has two simulation restaurants to provide the students with hands on food &amp; beverage service skills, also we have a mock bar, and we also do have a tie up with the Bar Academy, Delhi to impart bar tending to the students. The following are the food and Beverage labs that are there in the institute.</p>
                        <ul>
                            <li>Advanced Training Restaurant.</li>
                            <li>Basic Training Restaurant</li>
                            <li>Mock Bar</li>  
                        </ul>