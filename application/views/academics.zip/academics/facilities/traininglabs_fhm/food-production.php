<ul>
                        <li>Basic Training Kitchen.</li>
                            <li>Quantity Training Kitchen area.</li>
                            <li>Advance Training Kitchen.</li>
                            <li>Larder.</li>
                            <li>Demo Kitchen</li>
                            <li>Cafeteria Kitchen</li>
                            <li>Bakery &amp; Confectionary</li>	 
                    </ul>

                    <p align="justify"><b>All these above mentioned kitchens are well equipped with the following major equipments.</b></p>
                        <ul>
                            <li>Range -High pressure</li>
                            <li>Refrigerator 5door</li>
                            <li>Deep fat fryer</li>
                            <li>Salamander</li>
                            <li>OTG</li>
                            <li>Mincing machine</li>
                            <li>Electric juicer</li>
                            <li>Deep freezer</li>
                        </ul>