<ul>
	<li>
The institute also has state of the art audio visual lab with LCD projector, and OHP facility
</li>
</ul>