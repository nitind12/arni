	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/medical.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>A healthy body makes for a healthy mind. To ensure your well being, the campuses have tie ups with renowned hospitals in the city to take care of any emergency, whatsoever</li>     
                        <li>You will also be covered by a Insurance to meet all kinds of exigencies </li>
                    </ul>
            </div>