	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/cafetaria.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>What you eat is what you are! A healthy mind can only reside in a healthy body. We, at Amrapali, understand. Hence, all cafeterias have menus that are designed by a team of professional </li> 
                        <li>Fresh fruit juices, milkshakes, ice creams, snacks are available in these cafeteria for those energy boosts                      </li> 
                        <li>The Kiosk of Nescafe adds on to your happy moments.</li>
                    </ul>
            </div>