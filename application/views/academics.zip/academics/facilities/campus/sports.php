	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/sports.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>The industry today seeks not just knowledge workers, but action oriented leaders who adapt to changing situations with ease </li>   
                        <li>The infrastructure has been designed with exceptional facilities for sports as well as recreational activities to ensure that you are groomed to become just that</li> 
                        <li>Across campuses, Amrapali has top sports facilities including:
                            Athletics, Basketball, Cricket, Volleyball, Football
                        </li>
                    </ul>
            </div>