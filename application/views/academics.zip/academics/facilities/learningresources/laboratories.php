	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/laboratory.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>Amrapali has over more than 70 state-of-the-art labs as per the norms of AICTE and affiliating University that allow the students to experiment and bring to practice what they have learnt in theory		 </li>	 
                    </ul>
            </div>