<section class="trusted-client-wrapper">
                                
                                    <div class="col-md-8">
                                        <h6><?php echo $breadcrumb; ?></h6>
                                        <h2 class="section-title wow fadeInDown" ><?php echo $title;?></h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                                                               
                                            <p>Text here. </p>
                                            
                                        
                                        </div><!-- /.col-md-4 -->                               
                                    </div>
                                    <div class="col-md-4">
                                        <h2 class="section-title wow fadeInDown" >Arni Edge</h2>
                                        <div class="col-md-12" style="border: #fff solid 0px">
                                            <ul class="list-group">
                                                <li class="list-group-item" style="padding:5px!important;">200+ Expert Instructors</li>
                                                <li class="list-group-item" style="padding:5px!important;">State of Art Infrastructure</li>
                                                <li class="list-group-item" style="padding:5px!important;">Ultra-modern class rooms</li>
                                                <li class="list-group-item" style="padding:5px!important;">Elegant and well stocked library</li>
                                                <li class="list-group-item" style="padding:5px!important;">Wi-Fi Campus</li>
                                                <li class="list-group-item" style="padding:5px!important;">Multi-purpose Gyms</li>
                                                <li class="list-group-item" style="padding:5px!important;">Modern canteen</li>
                                                <li class="list-group-item" style="padding:5px!important;">Well maintained hostels</li>
                                                <li class="list-group-item" style="padding:5px!important;">Industry 4.0 curriculum</li>
                                                <li class="list-group-item" style="padding:5px!important;">Campus placement facility</li>
                                            </ul>                                    
                                        </div><!-- /.col-md-4 -->                               
                                    </div>

                                    <div class="col-md-12" style="clear: both"></div>
                                    
                                    <div class="col-md-12" style="clear: both; padding: 10px 0px"></div>
                               
                                <div style="clear:both"></div>
                                    
                            </section>