<h3>Apply Now <span style="font-size: 12px">(Admission <?php echo date('Y');?>-<?php echo (date('y')+1); ?>)</span>
<div style="float: right; color: #ff0000"><?php if($this->session->flashdata('msg')){ echo $this->session->flashdata('msg'); } ?></div></h3>
<div <?php echo $class_;?>>

<div class="col-sm-12 applynowNew" style="height: 700px">
    <script src="https://eequeuestorage.blob.core.windows.net/staticfiles/amrapali/ee-form-widget/form-1/widget.js"></script>
    
</div>
</div>