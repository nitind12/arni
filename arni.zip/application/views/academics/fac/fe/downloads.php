<h3>Downloads</h3>
<p style="text-align: center">
    <b>"Education is the manifestation of the perfection already in man."  - Swami Vivekanada</b>
</p>
<p>
    <ul>
        <li class="my-strips"><a href="https://ncte.gov.in" class="anchor-color-dark" target="_blank">Councils website</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/002.pdf');?>" class="anchor-color-dark">Details of sanctioned programme along-with annual intake</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/003.pdf');?>" class="anchor-color-dark">Details of faculty </a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/004.pdf');?>" class="anchor-color-dark">Details of students</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/005.pdf');?>" class="anchor-color-dark">Details of available infrastructure facilities</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/006.pdf');?>" class="anchor-color-dark">Details of fee charged from students</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/008.pdf');?>" class="anchor-color-dark">Details of books in the library</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/009.pdf');?>" class="anchor-color-dark">Details of laboratory and lab</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/010.pdf');?>" class="anchor-color-dark">Affidavit on Rs. 100/ stamp paper</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/011.pdf');?>" class="anchor-color-dark">Mandatory disclosure</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/012.pdf');?>" class="anchor-color-dark">Balance sheet 2018-19</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/013.pdf');?>" class="anchor-color-dark">Income /  expenditure 2018-19</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/014.pdf');?>" class="anchor-color-dark">Receipt and payment account 2018-19</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/015.pdf');?>" class="anchor-color-dark">Details of bio-metric data </a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/016.pdf');?>" class="anchor-color-dark">Student Detail 2019-21</a></li>
        <li class="my-strips"><a href="<?php echo base_url('assets/b_Ed/017.pdf');?>" class="anchor-color-dark">Faculty Member left/joined during last quarter</a></li>
    </ul>
</p>