	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/conference.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>The Conference  rooms provide a perfect setting for you to master team skills through exercises like brain-storming sessions, group discussions, role-plays etc.	 </li>		 
                    </ul>
            </div>