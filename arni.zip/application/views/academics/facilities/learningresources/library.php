<div class="col-sm-4">
	<ul>
	<img class="img-responsive" hspace="10" vsapce="10" src="<?php echo base_url('assets/img/lib.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>14292 titles and 99083 volumes</li>
                        <li>209 print-journals and magazines</li>
                        <li>CDs' (Books/Journal) (Books/Magazine) Project Report </li>
                        <li>UBKS Series Lectures Cds/DVDs on Management</li>
                        <li>Access to NPTEL Study Material for users</li>
                        <li>News Papers (National and Regional)</li>
                        <li>Indian and foreign text and reference books</li>
                        <li>E-Library with electronic databases</li>
                        <li>Access to Developing Library Network (DELNET)</li>
                        <li>Access to OPAC facility</li>
                        <li>Multimedia Sections for Users</li>
                        <li>Encyclopaedias and Map Sets</li>
                        <li>Documentation & Newspaper-clippings sections</li>
                        <li>Reprographic facility and Reading hall</li>
                        <li>Access to Online Full Text e-Journals</li>
                    </ul>
            </div>