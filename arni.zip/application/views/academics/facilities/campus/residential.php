	<div class="col-sm-4">
		<ul>
	<img class="img-responsive" src="<?php echo base_url('assets/img/hstl.jpg');?>">
</ul>
</div>
<div class="col-sm-8">
                    <ul>
                        <li>At Amrapali, you will be among the many students coming from all across the country to live in campus hostels, which are developed to be as home away from home</li>	 
                        <li>The Institute has separate facilities for boys and girls, the wardens are real care takers and in house dining ensures a pleasant stay allowing students to focus on their academics</li>
                        <li>Whilst internet access and good mobile connectivity ensure close contact with family and friends outside	</li>
                        <li>The common rooms are fully equipped with TV, </li>
                        <li>The hostel also have Gym, indoor games and other recreation facilities</li>
                    </ul>
            </div>