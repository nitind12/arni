<ul>
	<li>Advanced Computer Architecture</li>
                      <li>Distributed Systems</li>
                      <li>Computer Baed Numerical and Statistical Techniques</li>
                      <li>Unix &amp; Shell Programming </li>
                      <li>Compiler Design</li>
                      <li>Computer Graphics</li>
                      <li>Design and Analysis of Algorithms</li>
                      <li>Data Structure using C</li>
                      <li>Introduction to Web Technology</li>
                      <li>Object Oriented Programming using C++</li>
                      <li>Database Management Systems</li>
                      <li>Operating Systems</li>
                      <li>Artificial Intelligence and Computer Networks </li>
                      <li>Java</li>
</ul>