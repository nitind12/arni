<p align="justify">The institute has a well equipped computer lab The institute is providing IT-enabled functional services to its faculty, employees as well as students through centralised database management system under client-server architecture. IT infrastructure created in the campus provides ambience for resource sharing such as networked file and print services, mail services, student feedback system, centralised maintenance management, administrative services etc. on the network.</p>
						<ul style="text-align: justify;">
                        	<li>
                        		The institute provides uninterrupted internet services to all its employees, faculty. The hostel is equipped with internet, file and print services. The student can have access to these services through his / her own computer, and also through the centralised lab. The institute has an internet leased bandwidth of 2 Mbps availed from Radio Link connectivity, with necessary backup. Also Wi fi network is provided within the campus.
                        	</li>
                            <li>
                            	Web services at the Institute aim at catering to the needs of all the stakeholders and Institute constantly updates its site to meet the dynamic requirement. Library search services will be soon available through web. Besides these facilities also the Institutes alumni network is linked to the web site in order to provide better networking among the current students and alumni. Effort is on to make it interactive so that it offers on-line access to prospective candidates to the various courses offered at the institute also how to deal with the issues such as the admission process, availability of application forms, admit cards, publication of results etc.
                            </li>
                            <li>
                            	Computer Center has an Array of Computers upgraded constantly in tune with the changing times, capable of high resolution display and high speed data processing. The Centre is geared to provide the environment required for BHM &amp; DHM courses as well as the simulated business environment required for the courses. The centre introduces real life computing and illustrating the practical benefits of information technology.
                        	</li>
                        	<li>
                            	Software's are maintained in the lab and students are encouraged to use this facility to enhance their information handling capabilities. The software packages are regularly updated. Some of the software that are currently available are MS DOS-6.22, Win-98/2000, Win NT, MS Office, Visual Studio 6.0/7.0 and Hospitality software's etc.
                            </li>
                            <li>
                            	Also the institute has self developed PMS software for student routine practice is also available through LAN.
                            </li>
                        </ul>