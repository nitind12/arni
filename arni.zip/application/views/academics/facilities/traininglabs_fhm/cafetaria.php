<ul>
	<li>
The institute has a cafeteria that provides with healthy, hygienic and nutritional meals at nominal rates to the students
</li>
</ul>