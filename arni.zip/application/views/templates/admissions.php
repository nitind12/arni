<div class="links-border" style="background: #900900">
	<a href="<?php echo site_url('#');?>" class="a_" style="font-size: 19px">Interest Free EMI</a>
</div>
<div style="clear: both; padding: 3px 0px"></div>
<div class="links-border">
	<a href="<?php echo site_url('#');?>" class="a_">Admission Procedure</a>
</div>
<div style="clear: both; padding: 3px 0px"></div>
<div class="links-border">
	<a href="<?php echo site_url('#');?>" class="a_">Fee & Eligibility</a>
</div>
<div style="clear: both; padding: 3px 0px"></div>
<div class="links-border">
	<a href="<?php echo site_url('#');?>" class="a_">Payment Modes</a>
</div>
<div style="clear: both; padding: 3px 0px"></div>
<div class="links-border">
	<a href="<?php echo site_url('#');?>" class="a_">Education Loan</a>
</div>
<div style="clear: both; padding: 3px 0px"></div>