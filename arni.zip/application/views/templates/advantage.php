<style>
    .advantage{
        font-size:40px;
        color:#010066;
    }
</style>
<div class="col-sm-2 text-center experiance-tab-content wow fadeInLeft">
                                            <h2 class="advantage"><?php echo (date('Y')-2010);?></h2>
                                            <p style="text-align:center">Years of Academic Excellence</p>
                                        </div><!--/.col-sm-2 -->
                                        
                                        <div class="col-sm-2 text-center experiance-tab-content wow fadeInRight">
                                            <h2 class="advantage">79+</h2>
                                            <p style="text-align:center">Faculty Members</p>
                                        </div><!--/.col-sm-2 -->
                                        <div class="col-sm-2 text-center experiance-tab-content wow fadeInRight">
                                            <h2 class="advantage">1200+</h2>
                                            <p style="text-align:center">Bright Students</p>
                                        </div><!--/.col-sm-2 -->
                                        <div class="col-sm-2 text-center experiance-tab-content wow fadeInRight">
                                            <h2 class="advantage">5200+</h2>
                                            <p  style="text-align: center">Glorious Alumni</p>
                                        </div><!--/.col-sm-6 -->
                                        <div class="col-sm-2 text-center experiance-tab-content wow fadeInLeft">
                                            <h2 class="advantage"><?php echo "4+";?></h2>
                                            <p style="text-align:center">Hostels</p>
                                        </div><!--/.col-sm-2 -->
                                        <div class="col-sm-2 text-center experiance-tab-content wow fadeInLeft">
                                            <h2 class="advantage"><?php echo "500+";?></h2>
                                            <p style="text-align:center">Research Papers</p>
                                        </div><!--/.col-sm-2 -->