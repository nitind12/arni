<html>
    <head>
        <title>Widget</title>
        <meta charset="utf-8"/>
        <script src="https://eequeuestorage.blob.core.windows.net/staticfiles/amrapali/ee-form-widget/form-1/widget.js"></script>
    </head>
    <body>
        
    </body>
</html>