
                                                    <h2>List of Benefits</h2>
                                                    <ul class="check-square" style="padding: 0px 0px 0px 50px !important">
                                                    	<li>Win Prizes, Trophies, Certificates, Cash Prizes.</li>
                                                        <li>Earn Scholarship for Higher Studies at AGI.</li>
                                                        <li>Get your Subject Doubts cleared by Experts.</li>
                                                        <li>Get passes for Celebrity Nights.</li>
                                                        <li>Get Invites for Carnival/ Cultural Fest/ Technical Fest/ Management Fest/ Hospitality Fest.</li>
                                                        <li>Get Notifications regarding various Competitive Examsl.</li>
                                                    </ul>
                                                    
                                                    





