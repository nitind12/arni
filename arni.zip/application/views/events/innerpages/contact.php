<p>&nbsp;</p>
                                                    <h2>Contact Detail</h2>
                                                    <h3>Following members may be contacted in case of doubt/ query regarding the activities </h3>
                                                    <ul class="check-square">
                                                    	<li>Ms. Priya Tiwari (8006517593)</li>
                                                        <li>Ms. Dakshata Jalal (7065372160)</li>
                                                        <li>Mr. Akash Singh (8755329452)</li>
                                                    </ul>