<style>
    .links_{float: left; background-color: #808080; padding: 2px 4px; border-radius: 5px}
    .a_{
        color: #ffff00 !important;
    }
    .contact_{
        background-color: #000A99;
    }
    .tele_{
        float: left;
    }
</style>
<h3>Winter Carnival 2021</h3>
                                                    <p>It has been 20 years since the founding of our state of Uttarakhand. The story of the state is also the story of our Institute. This period has seen the flourishing of Amrapali Group of Institutes Haldwani as it completes 21 years of its existence. Therefore, it is appropriate that we celebrate this relationship by organizing a Winter Carnival. </p>
                                                    <p>Given the situation, this 'Amrapali Winter Carnival' will be organized completely online. However, this will not dampen any excitement as we have planned a whole gamut of creative activities ranging from dancing, singing, poetry and painting to quizzing, photography, blogging and vlogging!</p>
                                                    <p>The theme of all activities shall be the state and the story of Uttarakhand. We invite you to join us in this happy endeavour and help make it a big success. We promise boundless fun and generous prizes!</p>
                                                    <p>&nbsp;</p>
            										<h2>List of Activities</h2>
                                                    <ul class="check-square">
                                                    	<li><a href="<?php echo site_url('wintercarnival/arules#_1');?>" style="color: #900000 !important">Dancing</a></li>
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_2');?>" style="color: #900000 !important">Singing /Poetry/Instruments</a></li>
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_3');?>" style="color: #900000 !important">Painting/ Sketching</a></li>
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_4');?>" style="color: #900000 !important">Photography</a></li>
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_5');?>" style="color: #900000 !important">Quiz</a></li>
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_6');?>" style="color: #900000 !important">Essay/ Blog Writing</a></li> 
                                                        <li><a href="<?php echo site_url('wintercarnival/arules#_7');?>" style="color: #900000 !important">Vlogging</a></li>
                                                        <div class="links_"><a href="<?php echo site_url('wintercarnival/register');?>" class="a_">Register here</a></div>
                                                        <div style="float: left; margin: 5px"></div>
                                                        <div class="links_ contact_"><a href="<?php echo site_url('wintercarnival/contact');?>" class="a_" style="color: #ffffff !important">Contact us</a></div>
                                                        <div style="float: left; margin: 5px"></div>
                                                        <div class="tele_"><a href="<?php echo site_url('events/telegram'); ?>" target="_blank"><img src="<?php echo base_url('assets/img/telegram.png');?>" style="border: #000990 solid 0px; width: 151px"></a></div>
                                                    </ul>