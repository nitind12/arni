
                                                    <p style="color: #000090">
                                                        Visit <a href="<?php echo site_url('sdp/register');?>" class="onlineReg">Online Registration</a> or call 9759670200, 9759670300, 9759670400 and 9759670500
                                                    </p>
                                                    <h4>Note</h4>
                                                    <ul class="check-square" style="padding: 0px 0px 0px 50px !important">
                                                    	<li>Amrapali Student Connect Programme is open for Students from Class 9- Class 12.</li>
                                                        <li>There is No Registration Fee.</li>
                                                        <li>Registered Students will get Notifications about various Activities through E Mails, SMS and Whatsapp.</li>
                                                    </ul>
                                                    
                                                    





