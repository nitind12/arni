<h3>Clubs & Societies</h3>
<div <?php echo $class_;?>>
	<h5>Clubs and Societies</h5>
	<p>
		For the overall growth, students have opportunities to participate and compete in various extra and co-curricular activities, which help in holistic development of students. The various clubs at AGI are managed by student’s coordinators and supported by faculty in-charges. The Clubs are:
		<ul style="list-style-type: circle; padding: 0px 3%; text-align: justify;">
			<li>Robotics Club </li>
			<li>Codex Club</li>
			<li>AlMA Students Chapter </li>
			<li>Marketing  Club</li>
			<li>Finance Club</li>
			<li>HR Club</li>
			<li>Gourmet – The Culinary Club </li>
			<li>Futuristic - The F & B Club </li>
			<li>Hospitality -The Front Office Club </li>
			<li>Entrepreneurship Club</li>
			<li>Arogya - Health and Wellness Club </li>
			<li>Malhar - Cultural Club</li>
			<li>Pulp Fiction -Literary  Club </li>
			<li>Prayas -The Social Initiative Club </li>
			<li>Chhavi -  Photographic  Club </li>
			<li>NSS</li>
			<li>Alumni Association </li>
			<li>SPICMACAY</li>
		</ul>
	</p>
</div>